import multiprocessing as mp
import numpy as np


class Worker(mp.Process):

    def __init__(self, wid, in_q, out_q, vs, rrset_func):
        super(Worker, self).__init__(target=self.start)
        self.wid = wid
        self.in_q = in_q
        self.out_q = out_q
        self.vs = vs
        self.rrset_func = rrset_func

    def run(self):
        buffer = []
        n = len(self.vs)

        while True:
            cnt = self.in_q.get()
            while cnt > 0:
                r = np.random.randint(n)
                rrset = self.rrset_func(self.vs, r)
                if rrset:
                    buffer.append(rrset)
                    cnt -= 1
            self.out_q.put(buffer)
            buffer = []
