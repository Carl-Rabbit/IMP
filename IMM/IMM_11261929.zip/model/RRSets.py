class MaxHeap:

    def __init__(self, size):
        self.arr = [()]