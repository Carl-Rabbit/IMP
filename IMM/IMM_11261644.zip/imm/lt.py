import time
from typing import Set, List

import numpy as np

from model.vertex import Vertex


def get_lt_rrset(vs: List[Vertex], seed: int) -> Set:
    ret = set()
    cur = vs[seed]
    while cur.in_edges:
        in_degree = len(cur.in_edges)
        r = np.random.randint(in_degree)
        idx = cur.in_edges[r]
        if idx in ret:
            break
        cur = vs[idx]
        ret.add(idx)
    return ret
