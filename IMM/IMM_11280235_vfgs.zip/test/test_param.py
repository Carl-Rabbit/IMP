from imm.param import get_logc
from refer.IMP import log_comb

if __name__ == '__main__':
    n = 1023443
    k = 342224
    print(get_logc(n, k))
    print(log_comb(n, k))
