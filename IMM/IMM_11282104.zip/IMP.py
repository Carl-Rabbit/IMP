# -*- coding: utf-8 -*-
from imm.main import imm_main

if __name__ == '__main__':
    imm_main()
