import time
import random
from typing import Set, List

import numpy as np

from model.vertex import Vertex


def get_ic_rrset(vs: List[Vertex], seed: int) -> Set:
    active_set = {seed}
    actived = active_set.copy()
    ret = set()

    while active_set:
        new_set = set()
        for u_idx in active_set:
            u = vs[u_idx]
            in_degree = len(u.in_edges)
            if in_degree == 0:
                continue
            weight = 1 / in_degree
            r_list = np.random.random(in_degree)
            for v_idx, rand in zip(u.in_edges, r_list):
                if v_idx in actived:
                    continue
                if rand >= weight:
                    # not active
                    continue
                # active
                actived.add(v_idx)
                ret.add(v_idx)
                new_set.add(v_idx)
        active_set = new_set

    return ret
