import time
import random
from typing import Set, List

import numpy as np

from model.vertex import Vertex


def get_ic_rrset(vs: List[Vertex], index: int) -> Set:
    seed = vs[index]
    active_set = {seed}
    actived = active_set.copy()
    ret = set()

    while active_set:
        new_set = set()
        for u in active_set:
            in_degree = len(u.in_edges)
            if in_degree == 0:
                continue
            weight = 1 / in_degree
            r_list = np.random.randn(in_degree)
            for v, rand in zip(u.in_edges, r_list):
                if v in actived:
                    continue
                if rand > weight:
                    # not active
                    continue
                # active
                actived.add(v)
                ret.add(v.idx)
                new_set.add(v)
        active_set = new_set

    return ret
