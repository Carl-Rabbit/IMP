import sys
import time
from collections import Counter
from math import ceil
from typing import List, Set

import numpy as np

from imm.ic import get_ic_rrset
from imm.lt import get_lt_rrset
from model.network import Network
from utils.utils import param_parse, read_lines, print_tmp

CORE = 8
TIME_LEFT = 6

INIT_EP = 0.5 * np.sqrt(2)
INIT_L = 1


def imm_main():
    file_name, seed_cnt, model, time_limit = param_parse()
    timestamp_limit = time.time() + time_limit - TIME_LEFT

    # print_tmp('Params:', file_name, seed_cnt, model, time_limit)

    network_lines = read_lines(file_name)

    run(network_lines, seed_cnt, model, timestamp_limit)

    sys.stdout.flush()


def run(network_lines, k, model, timestamp_limit):
    if model == 'IC':
        get_rrset = get_ic_rrset
    elif model == 'LT':
        get_rrset = get_lt_rrset
    else:
        raise Exception('model type error')

    network: Network = Network(network_lines)
    network_lines = None

    l = INIT_L * (1 + np.log(2) / np.log(network.n))
    ep = INIT_EP

    rrsets: List[Set] = sampling(network, k, ep, l, get_rrset)
    seeds: Set = node_selection(rrsets, k)

    print('\n'.join([str(i) for i in seeds]))


def sampling(network: Network, k, ep, l, rrset_func) -> List[Set]:
    vs, n, m = network.vs, network.n, network.m

    # rrset = set()
    # lb = 1
    # for i in range(1, np.log2()):
    #     pass

    theta = ceil(1 * n)
    rrsets = []
    idx_set = set()
    for _ in range(theta):  # todo mp
        while True:
            r = np.random.randint(n)
            if r not in idx_set:
                break
        idx_set.add(r)
        rrset = rrset_func(vs, r)
        rrsets.append(rrset)

    return rrsets


def node_selection(rrsets: List[Set], k) -> Set:
    """
    Greedy select k nodes from rrsets
    :param rrsets: the set of RR sets
    :param k: the size of return set
    :return: the vertexes that we select
    """
    ret = set()
    for _ in range(k):
        flat_list = [item for rrset in rrsets for item in rrset]
        seed = Counter(flat_list).most_common()[0][0]
        ret.add(seed)

        # remove rrset that contains seed
        rrsets = [rrset for rrset in rrsets if seed not in rrset]

    return ret
