from typing import List

from model.vertex import Vertex


class Network:

    def __init__(self, network_lines):

        v_no, e_no = network_lines[0].split(' ')
        self.n, self.m = int(v_no), int(e_no)
        self.vs = [Vertex(idx) for idx in range(self.n)]

        for line in network_lines[1:]:
            frm_id, to_id, _ = line.split(' ')
            frm = self.vs[int(frm_id) - 1]
            to = self.vs[int(to_id) - 1]
            to.in_edges.append(frm)

