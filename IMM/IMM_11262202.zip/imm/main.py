import random
import sys
import time
from collections import Counter
from math import ceil
from typing import List, Set

import numpy as np
import multiprocessing as mp

from imm.ic import get_ic_rrset
from imm.lt import get_lt_rrset
from imm.param import get_lamb_p, get_lamb_s
from imm.worker import Worker
from model.network import Network
from utils.utils import param_parse, read_lines, print_tmp, write_lines

CORE = 8
TIME_LEFT = 6

INIT_E = 0.1
INIT_L = 1

rrset_func = get_ic_rrset
workers: List[Worker]


def imm_main():
    file_name, seed_cnt, model, time_limit = param_parse()
    timestamp_limit = time.time() + time_limit - TIME_LEFT

    # print_tmp('Params:', file_name, seed_cnt, model, time_limit)

    network_lines = read_lines(file_name)

    run(network_lines, seed_cnt, model, timestamp_limit)

    sys.stdout.flush()


def run(network_lines, k, model, timestamp_limit):
    global rrset_func

    if model == 'IC':
        rrset_func = get_ic_rrset
    elif model == 'LT':
        rrset_func = get_lt_rrset
    else:
        raise Exception('model type error')

    network: Network = Network(network_lines)
    network_lines = None
    e = INIT_E
    l = INIT_L * (1 + np.log(2) / np.log(network.n))

    create_workers(network.vs)

    # step 1
    t0 = time.time()
    rrsets: List[Set] = sampling(network, k, e, l)
    # step 2
    # print(f'len(rrsets) = {len(rrsets)}')
    t1 = time.time()
    seeds = node_selection(rrsets, k)
    t2 = time.time()

    # print(f't1 - t0: {t1 - t0}\nt2 - t1: {t2 - t1}')

    terminate_workers()

    # remember to + 1 because I store the index begin at 0
    output_lst = [str(i + 1) for i in seeds]
    print('\n'.join(output_lst))

    # print('write to test folder')
    # write_lines('../DatasetOnTestPlatform/my_' + str(model).lower() + '_seeds.txt', output_lst)


def create_workers(vs):
    global rrset_func, workers

    workers = []
    for i in range(CORE):
        worker = Worker(i, mp.Queue(), mp.Queue(), vs, rrset_func)
        workers.append(worker)
        worker.start()


def terminate_workers():
    for w in workers:
        w.terminate()


def sampling(network: Network, k, e, l) -> List[Set]:
    vs, n, m = network.vs, network.n, network.m
    rrsets: List[Set] = []

    lb = 1
    ep = e * np.sqrt(2)
    for i in range(1, ceil(np.log2(n)) + 1):
        x = n / (2**i)
        theta_i = get_lamb_p(n, k, ep, l) / x
        # print(f'theta_i: {theta_i}')
        fill_rrsets(rrsets, theta_i)

        s_k = node_selection(rrsets, k)
        fr = get_fr(rrsets, s_k)
        if n * fr >= (1 + ep) * x:
            lb = n * fr / (1 + ep)
            break

    theta = get_lamb_s(n, k, e, l) / lb
    # print(f'theta: {theta}')
    fill_rrsets(rrsets, theta)
    # print(f'fill finished')

    return rrsets


def node_selection(rrsets: List[Set], k):
    """
    Greedy select k nodes from rrsets
    :param rrsets: the set of RR sets
    :param k: the size of return set
    :return: the vertexes that we select (Sk)
    """
    s_k = set()
    rrsets_size = len(rrsets)

    vtx2sid_set = {}
    for rrset, sid in zip(rrsets, range(rrsets_size)):
        for vid in rrset:
            if vid not in vtx2sid_set:
                vtx2sid_set[vid] = {sid}
            else:
                vtx2sid_set[vid].add(sid)

    vtx2fq = {vid: len(sid_set) for vid, sid_set in vtx2sid_set.items()}

    for _ in range(k):

        max_vid = None
        max_fq = -1
        for vid, sid_set in vtx2sid_set.items():
            size = len(sid_set)
            if size > max_fq:
                max_fq = size
                max_vid = vid

        # print(max_vid, max_fq)

        s_k.add(max_vid)
        for sid in vtx2sid_set[max_vid]:
            for vid in rrsets[sid]:
                if vid != max_vid:
                    # now this vid need to be updated
                    vtx2sid_set[vid].remove(sid)
                    vtx2fq[vid] -= 1

        del vtx2sid_set[max_vid]
        del vtx2fq[max_vid]

    return s_k


def get_fr(rrsets: List[Set], s_k: Set) -> float:
    count = 0
    for rrset in rrsets:
        if rrset.intersection(s_k):
            count += 1
    return count / len(rrsets)


def fill_rrsets(rrsets: List[Set], size):
    """
    Add rrset to rrsets until len(rrsets) > size
    """
    global rrset_func, workers

    cnt = int(size) + 1 - len(rrsets)

    # print(f'before {len(rrsets)}')

    if cnt <= CORE:
        # not np
        w = workers[0]
        w.in_q.put(cnt)
        w_ret = w.out_q.get()
        # print(f'worker {w.wid} <- {len(w_ret)}')
        rrsets += w_ret
    else:
        num = int(cnt / CORE) + 1
        for w in workers:
            w.in_q.put(num)
        for w in workers:
            w_ret = w.out_q.get()
            # print(f'worker {w.wid} <- {len(w_ret)}')
            rrsets += w_ret

    # print(f'after {len(rrsets)}')
