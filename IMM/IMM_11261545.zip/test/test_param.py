from imm.param import get_logc

if __name__ == '__main__':
    logc = get_logc(10, 2)
    print(logc)