class MaxHeap:

    def __init__(self, size):
        # (vid, sid_list)
        self.arr = [None] * (size + 1)


