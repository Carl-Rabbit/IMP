# -*- coding: utf-8 -*-
from ise.main import ise_main

if __name__ == '__main__':
    ise_main()
