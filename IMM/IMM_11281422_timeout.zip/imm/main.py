import sys
import time
from typing import List

# from memory_profiler import profile

from imm.ic import get_ic_rrset
from imm.lt import get_lt_rrset
from imm.worker import Worker
from model.network import Network
from utils.utils import param_parse
from utils.utils import write_lines

import multiprocessing as mp

CORE = 6
TIME_LEFT = 10

MEM_LIMIT = 1000 * (2 ** 20)
PHARSE_NUM = 64

INIT_E = 0.1
INIT_L = 1

rrset_func = get_ic_rrset
workers: List[Worker]

start_time: float
time_limit: float

heap: List[List]
top_idx: int


def imm_main():
    global start_time, time_limit

    file_name, seed_cnt, model, time_limit = param_parse()

    # time_limit *= 10      # for test

    start_time = time.time()

    # print_tmp('Params:', file_name, seed_cnt, model, time_limit)

    # network_lines = read_lines(file_name)
    # run(network_lines, seed_cnt, model)

    network = Network()
    with open(file_name, 'r') as fp:
        network.parse_first_line(fp.readline())
        for _ in range(network.m):
            network.parse_data_line(fp.readline())
    run('', seed_cnt, model, network)

    sys.stdout.flush()
    # print('time cost: ', time.time() - start_time)


# @profile
def run(network_lines, k, model, network_input=None):
    global rrset_func, heap, top_idx

    if model == 'IC':
        rrset_func = get_ic_rrset
    elif model == 'LT':
        rrset_func = get_lt_rrset
    else:
        raise Exception('model type error')

    network: Network

    if network_input:
        network = network_input
    else:
        network = Network(network_lines)

    # e = INIT_E
    # l = INIT_L * (1 + np.log(2) / np.log(network.n))

    create_workers(network.vs)

    # step 1
    # t0 = time.time()
    # rrsets: List[Set] = sampling(network, k, e, l)
    rrsets: List[List] = sampling(network, k)

    terminate_workers()

    del network

    # step 2
    # print(f'len(rrsets) = {len(rrsets)}')

    # t1 = time.time()
    # init vtx2sid_lst
    vtx2sid_lst = {}
    sid = 0
    for rrset in rrsets:
        for vid in rrset:
            if vid not in vtx2sid_lst:
                vtx2sid_lst[vid] = [sid]
            else:
                vtx2sid_lst[vid].append(sid)
        sid += 1
        del rrset

    del rrsets

    # init heap
    top_idx = len(vtx2sid_lst) + 1
    heap = [[] for _ in range(top_idx)]       # max heap for [vid, score, sid_lst]

    idx = len(heap) - 1
    for vid, sid_lst in vtx2sid_lst.items():
        score = len(sid_lst)
        heap[idx] += [vid, score, sid_lst]
        shift_down(idx)
        idx -= 1

    del vtx2sid_lst

    # t2 = time.time()

    # node selection
    seeds = node_selection(k)
    # t3 = time.time()

    # print(f'sampling: {t1 - t0}\ninit heap: {t2 - t1}\nselection: {t3 - t2}')

    # remember to + 1 because I store the index begin at 0
    output_lst = [str(i + 1) for i in seeds]
    print('\n'.join(output_lst))

    # print('write to test folder')
    # write_lines('../DatasetOnTestPlatform/my_' + str(model).lower() + '_seeds.txt', output_lst)


def create_workers(vs):
    global rrset_func, workers

    workers = []
    for i in range(CORE):
        worker = Worker(i, mp.Queue(), mp.Queue(), vs, rrset_func)
        workers.append(worker)
        worker.start()


def terminate_workers():
    for w in workers:
        w.terminate()


# def sampling(network: Network, k, e, l) -> List[Set]:
#     vs, n, m = network.vs, network.n, network.m
#     rrsets: List[Set] = []
#
#     lb = 1
#     ep = e * np.sqrt(2)
#     for i in range(1, ceil(np.log2(n)) + 1):
#         x = n / (2**i)
#         theta_i = get_lamb_p(n, k, ep, l) / x
#         # print(f'theta_i: {theta_i}')
#         fill_rrsets(rrsets, theta_i)
#
#         s_k = node_selection(rrsets, k)
#         fr = get_fr(rrsets, s_k)
#         if n * fr >= (1 + ep) * x:
#             lb = n * fr / (1 + ep)
#             break
#
#     theta = get_lamb_s(n, k, e, l) / lb
#     # print(f'theta: {theta}')
#     fill_rrsets(rrsets, theta)
#     # print(f'fill finished')
#
#     return rrsets


def sampling(network: Network, k) -> List[List]:
    global start_time, time_limit, MEM_LIMIT, rrset_func, workers

    rrsets: List[List] = []

    time_for_sampling = 0.3 * time_limit

    if network.n > 8_0000:
        # deal with large graph
        time_for_sampling = 0.25 * time_limit
        MEM_LIMIT *= 0.8
    elif network.n > 3_5000:
        MEM_LIMIT *= 1.0
    elif network.n < 2_0000:
        MEM_LIMIT *= 1.4

    # print('time_for_sampling = ', time_for_sampling)

    time_bound = start_time + time_for_sampling

    # fill_rrsets(rrsets, time_bound, network)

    # Add rrset to rrsets until len(rrsets) > size

    finished_workers = set()
    finished_worker_cnt = 0

    MEM_LIMIT -= CORE * network.get_est_size()

    for w in workers:
        w.in_q.put((time_bound, PHARSE_NUM, int(MEM_LIMIT / CORE)))

    while finished_worker_cnt != CORE:
        for w in workers:
            if w in finished_workers:
                continue
            flag, w_ret = w.out_q.get()
            if flag == -1:
                finished_worker_cnt += 1
                finished_workers.add(w)
                continue
            # print(f'worker {w.wid} <- {flag} {len(w_ret)}')
            rrsets += w_ret

    # print(f'size target = {MEM_LIMIT / 2 ** 20}, '
    #       f'act = {sum([sys.getsizeof(rrset) for rrset in rrsets]) / 2 ** 20}')

    return rrsets


# def node_selection(rrsets: List[List], k):
#     """
#     Greedy select k nodes from rrsets
#     :param rrsets: the set of RR sets
#     :param k: the size of return set
#     :return: the vertexes that we select (Sk)
#     """
#     s_k = []
#
#     vtx2sid_set = {}
#     sid = 0
#     for rrset in rrsets:
#         for vid in rrset:
#             if vid not in vtx2sid_set:
#                 vtx2sid_set[vid] = {sid}
#             else:
#                 vtx2sid_set[vid].add(sid)
#         sid += 1
#
#     for _ in range(k):
#
#         if not vtx2sid_set:
#             break
#
#         max_vid = None
#         max_fq = -1
#         for vid, sid_set in vtx2sid_set.items():
#             size = len(sid_set)
#             if size > max_fq:
#                 max_fq = size
#                 max_vid = vid
#
#         # print(max_vid, max_fq)
#
#         s_k.append(max_vid)
#         for sid in vtx2sid_set[max_vid]:
#             for vid in rrsets[sid]:
#                 if vid != max_vid:
#                     # now this vid need to be updated
#                     vtx2sid_set[vid].remove(sid)
#
#         del [vtx2sid_set[max_vid]]
#
#     return s_k

def shift_down(i):
    global top_idx, heap

    while True:
        left_idx = 2 * i
        if left_idx >= top_idx:
            return
        right_idx = 2 * i + 1
        if right_idx >= top_idx:
            max_idx = left_idx
        else:
            if heap[left_idx][1] > heap[right_idx][1]:
                max_idx = left_idx
            else:
                max_idx = right_idx

        if heap[i][1] >= heap[max_idx][1]:
            return

        heap[i], heap[max_idx] = heap[max_idx], heap[i]

        i = max_idx


def node_selection(k):
    """
    Greedy select k nodes from rrsets
    :param k: the size of return set
    :return: the vertexes that we select (Sk)
    """
    global top_idx, heap

    s_k = []

    seed_cnt = 0
    covered_set = set()
    while seed_cnt < k:
        lst = heap[1]
        new_sid_lst = list(filter(lambda e: e not in covered_set, lst[2]))
        new_score = len(new_sid_lst)
        lst[1], lst[2] = new_score, new_sid_lst

        if new_score >= max(heap[2][1], heap[3][1]):
            vid = lst[0]

            top_idx -= 1
            heap[1] = heap[top_idx]
            shift_down(1)

            s_k.append(vid)
            seed_cnt += 1

            for sid in new_sid_lst:
                covered_set.add(sid)
        else:
            shift_down(1)

    return s_k


# def get_fr(rrsets: List[Set], s_k: Set) -> float:
#     count = 0
#     for rrset in rrsets:
#         if rrset.intersection(s_k):
#             count += 1
#     return count / len(rrsets)


# def fill_rrsets(rrsets: List[List], time_bound, network: Network):
#     """
#     Add rrset to rrsets until len(rrsets) > size
#     """
#     global rrset_func
#
#     vs, n = network.vs, network.n
#
#     left_size = RRSET_SIZE
#     while time.time() < time_bound and left_size >= 0:
#         count = int(RRSET_SIZE / 20) + 1
#         left_size -= count
#         r_list = np.random.randint(n, size=count)
#         while count > 0:
#             count -= 1
#             rrset = rrset_func(vs, r_list[count])
#             rrsets.append(rrset)
#
#     # print(f'size = {sum([sys.getsizeof(rrset) for rrset in rrsets])}')
