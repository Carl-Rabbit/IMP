import time
from typing import Set, List

import numpy as np

from model.vertex import Vertex


def get_lt_rrset(vs: List[Vertex], index: int) -> Set:
    ret = set()
    cur = vs[index]
    while cur.in_edges:
        in_degree = len(cur.in_edges)
        while True:
            r = np.random.randint(in_degree)
            idx = cur.in_edges[r].idx
            if idx not in ret:
                break
            if cur.in_edges:
                return ret
        cur = vs[idx]
        ret.add(idx)
    return ret
