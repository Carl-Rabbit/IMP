import sys
import time
from typing import List

from imm.ic import get_ic_rrset
from imm.lt import get_lt_rrset
from model.network import Network
from utils.utils import param_parse

import numpy as np

CORE = 8
TIME_LEFT = 10

RRSET_SIZE = 800_0000

INIT_E = 0.1
INIT_L = 1

rrset_func = get_ic_rrset
# workers: List[Worker]

start_time: float
time_limit: float

top_idx: int


def imm_main():
    global start_time, time_limit

    file_name, seed_cnt, model, time_limit = param_parse()

    # time_limit *= 10      # for test

    start_time = time.time()

    # print_tmp('Params:', file_name, seed_cnt, model, time_limit)

    # network_lines = read_lines(file_name)
    # run(network_lines, seed_cnt, model)

    network = Network()
    with open(file_name, 'r') as fp:
        network.parse_first_line(fp.readline())
        for _ in range(network.m):
            network.parse_data_line(fp.readline())
    run('', seed_cnt, model, network)

    sys.stdout.flush()
    # print('time cost: ', time.time() - start_time)


def run(network_lines, k, model, network_input=None):
    global rrset_func

    if model == 'IC':
        rrset_func = get_ic_rrset
    elif model == 'LT':
        rrset_func = get_lt_rrset
    else:
        raise Exception('model type error')

    network: Network

    if network_input:
        network = network_input
    else:
        network = Network(network_lines)

    # e = INIT_E
    # l = INIT_L * (1 + np.log(2) / np.log(network.n))

    # create_workers(network.vs)

    # step 1
    # t0 = time.time()
    # rrsets: List[Set] = sampling(network, k, e, l)
    rrsets: List[List] = sampling(network, k)

    # terminate_workers()

    # step 2
    # print(f'len(rrsets) = {len(rrsets)}')
    # t1 = time.time()
    seeds = node_selection(rrsets, k)
    # t2 = time.time()

    # print(f't1 - t0: {t1 - t0}\nt2 - t1: {t2 - t1}')

    # remember to + 1 because I store the index begin at 0
    output_lst = [str(i + 1) for i in seeds]
    print('\n'.join(output_lst))

    # print('write to test folder')
    # write_lines('../DatasetOnTestPlatform/my_' + str(model).lower() + '_seeds.txt', output_lst)


# def create_workers(vs):
#     global rrset_func, workers
#
#     workers = []
#     for i in range(CORE):
#         worker = Worker(i, mp.Queue(), mp.Queue(), vs, rrset_func)
#         workers.append(worker)
#         worker.start()
#
#
# def terminate_workers():
#     for w in workers:
#         w.terminate()


# def sampling(network: Network, k, e, l) -> List[Set]:
#     vs, n, m = network.vs, network.n, network.m
#     rrsets: List[Set] = []
#
#     lb = 1
#     ep = e * np.sqrt(2)
#     for i in range(1, ceil(np.log2(n)) + 1):
#         x = n / (2**i)
#         theta_i = get_lamb_p(n, k, ep, l) / x
#         # print(f'theta_i: {theta_i}')
#         fill_rrsets(rrsets, theta_i)
#
#         s_k = node_selection(rrsets, k)
#         fr = get_fr(rrsets, s_k)
#         if n * fr >= (1 + ep) * x:
#             lb = n * fr / (1 + ep)
#             break
#
#     theta = get_lamb_s(n, k, e, l) / lb
#     # print(f'theta: {theta}')
#     fill_rrsets(rrsets, theta)
#     # print(f'fill finished')
#
#     return rrsets


def sampling(network: Network, k) -> List[List]:
    global start_time, time_limit, RRSET_SIZE

    rrsets: List[List] = []

    # ratio = 2.0     # sampling : selection

    # time_for_sampling = (time_limit - TIME_LEFT) * ratio / (ratio + 2)  # left one
    time_for_sampling = 0.6 * time_limit
    # print('time_for_sampling = ', time_for_sampling)

    if network.n > 8_0000:
        # deal with large graph
        time_for_sampling = 0.6 * time_limit
        RRSET_SIZE *= 0.5

    time_bound = start_time + time_for_sampling

    fill_rrsets(rrsets, time_bound, network)
    # fill_rrsets(rrsets, time_bound)

    return rrsets


# def node_selection(rrsets: List[List], k):
#     """
#     Greedy select k nodes from rrsets
#     :param rrsets: the set of RR sets
#     :param k: the size of return set
#     :return: the vertexes that we select (Sk)
#     """
#     s_k = []
#
#     vtx2sid_set = {}
#     sid = 0
#     for rrset in rrsets:
#         for vid in rrset:
#             if vid not in vtx2sid_set:
#                 vtx2sid_set[vid] = {sid}
#             else:
#                 vtx2sid_set[vid].add(sid)
#         sid += 1
#
#     for _ in range(k):
#
#         if not vtx2sid_set:
#             break
#
#         max_vid = None
#         max_fq = -1
#         for vid, sid_set in vtx2sid_set.items():
#             size = len(sid_set)
#             if size > max_fq:
#                 max_fq = size
#                 max_vid = vid
#
#         # print(max_vid, max_fq)
#
#         s_k.append(max_vid)
#         for sid in vtx2sid_set[max_vid]:
#             for vid in rrsets[sid]:
#                 if vid != max_vid:
#                     # now this vid need to be updated
#                     vtx2sid_set[vid].remove(sid)
#
#         del [vtx2sid_set[max_vid]]
#
#     return s_k


def node_selection(rrsets: List[List], k):
    """
    Greedy select k nodes from rrsets
    :param rrsets: the set of RR sets
    :param k: the size of return set
    :return: the vertexes that we select (Sk)
    """
    global top_idx

    s_k = []

    vtx2sid_lst = {}
    sid = 0
    for rrset in rrsets:
        for vid in rrset:
            if vid not in vtx2sid_lst:
                vtx2sid_lst[vid] = [sid]
            else:
                vtx2sid_lst[vid].append(sid)
        sid += 1

    top_idx = len(vtx2sid_lst) + 1
    heap = [[] for _ in range(top_idx)]       # max heap for [vid, score, sid_lst]

    def shift_down(i):
        while True:
            left_idx = 2 * i
            if left_idx >= top_idx:
                return
            right_idx = 2 * i + 1
            if right_idx >= top_idx:
                max_idx = left_idx
            else:
                if heap[left_idx][1] > heap[right_idx][1]:
                    max_idx = left_idx
                else:
                    max_idx = right_idx

            if heap[i][1] >= heap[max_idx][1]:
                return

            heap[i], heap[max_idx] = heap[max_idx], heap[i]

            i = max_idx

    idx = len(heap) - 1
    for vid, sid_lst in vtx2sid_lst.items():
        score = len(sid_lst)
        heap[idx] += [vid, score, sid_lst]
        shift_down(idx)
        idx -= 1

    seed_cnt = 0
    covered_set = set()
    while seed_cnt < k:
        lst = heap[1]
        new_sid_lst = list(filter(lambda e: e not in covered_set, lst[2]))
        new_score = len(new_sid_lst)
        lst[1], lst[2] = new_score, new_sid_lst

        if new_score >= max(heap[2][1], heap[3][1]):
            vid = lst[0]

            top_idx -= 1
            heap[1] = heap[top_idx]
            shift_down(1)

            s_k.append(vid)
            seed_cnt += 1

            for sid in new_sid_lst:
                covered_set.add(sid)
        else:
            shift_down(1)

    return s_k


# def get_fr(rrsets: List[Set], s_k: Set) -> float:
#     count = 0
#     for rrset in rrsets:
#         if rrset.intersection(s_k):
#             count += 1
#     return count / len(rrsets)


def fill_rrsets(rrsets: List[List], time_bound, network: Network):
    """
    Add rrset to rrsets until len(rrsets) > size
    """
    global rrset_func

    vs, n = network.vs, network.n

    left_size = RRSET_SIZE
    while time.time() < time_bound and left_size >= 0:
        count = int(RRSET_SIZE / 20) + 1
        left_size -= count
        r_list = np.random.randint(n, size=count)
        while count > 0:
            count -= 1
            rrset = rrset_func(vs, r_list[count])
            rrsets.append(rrset)


# def fill_rrsets(rrsets: List[List], time_bound):
#     """
#     Add rrset to rrsets until len(rrsets) > size
#     """
#     global rrset_func, workers
#
#     for w in workers:
#         w.in_q.put((time_bound, int(RRSET_SIZE / CORE)))
#     for w in workers:
#         w_ret = w.out_q.get()
#         print(f'worker {w.wid} <- {len(w_ret)}')
#         rrsets += w_ret
