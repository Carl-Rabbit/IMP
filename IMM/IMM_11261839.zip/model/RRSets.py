class RRSets:

    def __init__(self):
        self.vtx2fq = {}
        self.vtx2set = {}